#include "eth/global.h"

char net_buffer[576];