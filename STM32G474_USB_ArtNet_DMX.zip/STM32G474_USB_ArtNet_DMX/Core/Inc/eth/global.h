#ifndef __ETH_GLOBAL_H_
#define __ETH_GLOBAL_H_

extern char net_buffer[576];

#endif